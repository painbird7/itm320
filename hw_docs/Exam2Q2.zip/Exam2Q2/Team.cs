﻿namespace Exam2Q2
{
    public class Team
    {

        public Team(string groupName, string semesterNo, Student.TeamLeader leader, Student.TeamDeputyLeader secondLeader, Student.TeamMember3 third, Student.TeamMember4 fourth)
        {
            GroupName = groupName;
            SemesterNo = semesterNo;
            MyLeader = leader;
            MySecondLeader = secondLeader;
            MyThird = third;
            MyFourth = fourth;
        }

        public string GroupName { get; set; }
        public string SemesterNo { get; set; }

        public Student.TeamLeader MyLeader { get; set; }
        public Student.TeamDeputyLeader MySecondLeader { get; set; }
        public Student.TeamMember3 MyThird { get; set; }
        public Student.TeamMember4 MyFourth { get; set; }

        public override string ToString()
        {
            return $"Group Name: {GroupName} \nSemester Number: {SemesterNo} \n{MyLeader} \n{MySecondLeader} \n{MyThird} \n{MyFourth}";
        }
    }
}