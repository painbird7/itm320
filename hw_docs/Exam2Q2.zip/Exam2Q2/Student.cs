﻿namespace Exam2Q2
{
    public class Student
    {
        public class TeamLeader
        {
            public TeamLeader(string studentFullName, string studentEmail)
            {
                StudentFullName = studentFullName;
                StudentEmail = studentEmail;
            }
            public string StudentFullName { get; set; }
            public string StudentEmail { get; set; }
            public override string ToString()
            {
                return $"Team Leader: {StudentFullName}, Email Address: {StudentEmail}";
            }
        }

        public class TeamDeputyLeader
        {
            public TeamDeputyLeader(string studentFullName, string studentEmail)
            {
                StudentFullName = studentFullName;
                StudentEmail = studentEmail;
            }
            public string StudentFullName { get; set; }
            public string StudentEmail { get; set; }

            public override string ToString()
            {
                return $"Team Deputy Leader: {StudentFullName}, Email Address: {StudentEmail}";
            }
        }

        public class TeamMember3
        {
            public TeamMember3(string studentFullName, string studentEmail)
            {
                StudentFullName = studentFullName;
                StudentEmail = studentEmail;
            }
            public string StudentFullName { get; set; }
            public string StudentEmail { get; set; }
            public override string ToString()
            {
                return $"Team Member3: {StudentFullName}, Email Address: {StudentEmail}";
            }
        }

        public class TeamMember4
        {
            public TeamMember4(string studentFullName, string studentEmail)
            {
                StudentFullName = studentFullName;
                StudentEmail = studentEmail;
            }
            public string StudentFullName { get; set; }
            public string StudentEmail { get; set; }
            public override string ToString()
            {
                return $"Team Member4: {StudentFullName}, Email Address: {StudentEmail}";
            }
        }

    }
}