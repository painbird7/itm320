﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2Q2
{
    public class Program
    {
        static void Main(string[] args)
        {
            Student.TeamLeader myTeamLeader = new Student.TeamLeader("Jay Han", "jayhan@u.boisestate.edu");
            Student.TeamDeputyLeader myTeamDeputyLeader = new Student.TeamDeputyLeader("Jesus Cervantes", "jesuscervantes348@u.boisestate.edu");
            Student.TeamMember3 myTeamMember3 = new Student.TeamMember3("Francine Loali", "francineloali@u.boisestate.edu");
            Student.TeamMember4 myTeamMember4 = new Student.TeamMember4("Evan Lewis", "evanlewis@u.boisestate.edu");

            Team myTeam = new Team("Linux", "SP2020", myTeamLeader, myTeamDeputyLeader, myTeamMember3, myTeamMember4);
            Console.WriteLine(myTeam);
            Console.ReadLine();
        }
    }
}
